function editProfile_open(i) {
    if (i == 'Pswd'){
        document.getElementById("passwordParam").style.display = "block";
    }
    if (i == 'Email'){
        document.getElementById("emailParam").style.display = "block";
    }
    if (i == 'Username'){
        document.getElementById("usernameParam").style.display = "block";
    }
    if (i == 'PasswordChk'){
        document.getElementById("passwordChk").style.display = "block";
    }
    document.getElementById("overlay").style.display = "block";
    document.getElementById("editProfile").style.display = "block";
}
function editProfile_close() {
    document.getElementById("overlay").style.display = "none";
    document.getElementById("editProfile").style.display = "none";
    document.getElementById("passwordParam").style.display = "none";
    document.getElementById("emailParam").style.display = "none";
    document.getElementById("usernameParam").style.display = "none";
    document.getElementById("passwordChk").style.display = "none";
}



function show(i){
  document.getElementById(`show${i}`).style.display = "none";
  document.getElementById(`hide${i}`).style.display = "inline-block";
}
function hide(i){
  document.getElementById(`show${i}`).style.display = "inline-block";
  document.getElementById(`hide${i}`).style.display = "none";
}



function getUserInfo(i){
    editProfile_open('PasswordChk')
    const callback = (responseStatus, responseData) => {
        console.log("responseStatus:", responseStatus);
            console.log("responseData:", responseData);
        if (responseStatus == 200) {
            return;
        } else {
          warningCard.classList.remove("d-none");
          warningText.innerText = responseData.message;
        }
      };
    
      const editProfile = document.getElementById("editProfile");
    
      const warningCard = document.getElementById("warningCard");
      const warningText = document.getElementById("warningText");
    
      editProfile.addEventListener("submit", function (event) {
          console.log("editProfile.addEventListener");
          event.preventDefault();
      
          const password = document.getElementById("PasswordChk").value;
          const data = {
              password: password
          };
  
          // Perform login request
          fetchMethod(currentUrl + `/api/users/${localStorage.getItem('username')}/${i}`, callback, "GET", data);
          // Reset the form fields
          editProfile.reset();
        })
}